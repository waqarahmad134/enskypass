<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="main-wrapper">
            <div class="col">
                <div class="card">
                    <div class="card-body">
                        <?php if(Session::has('message')): ?>
                        <p class="alert alert-<?php echo e(Session::get('alert')); ?>"><?php echo e(Session::get('message')); ?></p>
                        <?php endif; ?>
                        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-success">Back</a>
                        <h5>Edit Category</h5>
                        <form action="<?php echo e(route('category.update',['category'=>$category])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="mb-2">
                                <?php if(isset($category->parent_category) && $category->parent_category->count() > 0): ?>
                                    <label class="form-label">Parent Category</label>
                                    <select class="form-control" name="parent_id">
                                        <?php $__currentLoopData = $all_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($all_category->id); ?>" <?php if($category->parent_category->id == $all_category->id ): ?> selected <?php endif; ?> ><?php echo e($all_category->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                <?php endif; ?>
                            </div>
                            <input type="hidden" name="back_url" value="<?php echo e(url()->previous()); ?>">
                            <div class="mb-2">
                                <label class="form-label">Name</label>
                                <input class="form-control" type="text" name="name" value="<?php echo e($category->name ?? ""); ?>">
                            </div>
                            
                            <div class="mb-2">
                                <label class="form-label">Image</label>
                                <input class="form-control" type="file" name="image">
                            </div>
                            
                            <div class="mb-2">
                                <label class="form-label">Background Color</label>
                                <input type="color" name="color" value="<?php echo e($category->background_color ?? ""); ?>">
                            </div>
                            
                            <div class="mb-2">
                                <label class="form-label">Status</label>
                                <select class="form-control" name="status">
                                    <option value='1' <?php echo e($category->active == '1' ? 'selected':''); ?> >Active</option>
                                    <option value='0' <?php echo e($category->active == '0' ? 'selected':''); ?> >Disable</option>
                                </select>
                            </div>
                            
                            <button type="submit" class="btn btn-primary">Save Changes</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/devgloca/public_html/appsdashboard/resources/views/categorymanagement/edit_category.blade.php ENDPATH**/ ?>