<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="main-wrapper">
            <div class="row">
                <div class="col">
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <?php if(isset($stores) && $stores->count() > 0): ?>
                                <table class="table table-bordered table-hover js-basic-example dataTable table-custom" style="width: 100%;">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Name</th>
                                            <th>Description</th>
                                            <th>Email</th>
                                            <th>ZIP</th>
                                            <th>Address</th>
                                            <th>Phone</th>
                                            <th>Opening Closing Time</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($store->id); ?></td>
                                                <td><?php echo e($store->description); ?></td>
                                                <td><?php echo e($store->name); ?></td>
                                                <td><?php echo e($store->email); ?></td>
                                                <td><?php echo e($store->zip_code); ?></td>
                                                <td><?php echo e($store->address); ?></td>
                                                <td><?php echo e($store->mobile); ?></td>
                                                <td><?php echo e($store->opening_Closing_time); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th>ID</th>
                                            <th>Name</th>
                                            <th>Description</th>
                                            <th>Email</th>
                                            <th>ZIP</th>
                                            <th>Address</th>
                                            <th>Phone</th>
                                            <th>Opening Closing Time</th>
                                        </tr>
                                    </tfoot>
                                </table>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function myFunction() {
            alert("Do you really want to delete this country?");
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/devgloca/public_html/appsdashboard/resources/views/retailmanagement/all_retailer.blade.php ENDPATH**/ ?>