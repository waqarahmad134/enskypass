<?php $__env->startSection('content'); ?>

    <div id="main-content">
        <div class="block-header">
            <div class="row clearfix">
                <div class="col-md-6 col-sm-12">
                    <h2>Dashboard</h2>
                </div>
                <div class="col-md-6 col-sm-12 text-right">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.html"><i class="icon-home"></i></a></li>
                        <li class="breadcrumb-item active">Home</li>
                    </ul>
                    
                </div>
            </div>
        </div>

        <div class="container-fluid">

            <div class="row clearfix">

                <div class="col-lg-3 col-md-3 col-sm-3">
                    <div class="card top_report">
                        <div class="body">
                            <div class="clearfix">
                                <div class="float-left">
                                    <i class="fa fa-5x fa-users text-col-blue"></i>
                                </div>
                                <div class="number float-right text-right">
                                    <h6>Users</h6>
                                    <span class="font700">10</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-3">
                    <div class="card top_report">
                        <div class="body">
                            <div class="clearfix">
                                <div class="float-left">
                                    <i class="fa fa-5x fa-first-order text-col-blue"></i>
                                </div>
                                <div class="number float-right text-right">
                                    <h6>Orders</h6>
                                    <span class="font700">20</span>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-3">
                    <div class="card top_report">
                        <div class="body">
                            <div class="clearfix">
                                <div class="float-left">
                                    <i class="fa fa-5x fa-user-plus text-col-blue"></i>
                                </div>
                                <div class="number float-right text-right">
                                    <h6>Accepted Requests</h6>
                                    <span class="font700">50</span>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-3">
                    <div class="card top_report">
                        <div class="body">
                            <div class="clearfix">
                                <div class="float-left">
                                    <i class="fa fa-5x fa-refresh text-col-blue"></i>
                                </div>
                                <div class="number float-right text-right">
                                    <h6>Processing Orders</h6>
                                    <span class="font700">80</span>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

            <div class="row clearfix">

                <div class="col-lg-3 col-md-3 col-sm-3">
                    <div class="card top_report">
                        <div class="body">
                            <div class="clearfix">
                                <div class="float-left">
                                    <i class="fa fa-5x fa-star-half text-col-blue"></i>
                                </div>
                                <div class="number float-right text-right">
                                    <h6>Pending Orders</h6>
                                    <span class="font700">30</span>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-3">
                    <div class="card top_report">
                        <div class="body">
                            <div class="clearfix">
                                <div class="float-left">
                                    <i class="fa fa-5x fa-star-half-full text-col-blue"></i>
                                </div>
                                <div class="number float-right text-right">
                                    <h6>Completed Orders</h6>
                                    <span class="font700">250</span>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-3">
                    <div class="card top_report">
                        <div class="body">
                            <div class="clearfix">
                                <div class="float-left">
                                    <i class="fa fa-5x fa-star-o text-col-blue"></i>
                                </div>
                                <div class="number float-right text-right">
                                    <h6>Over All User Rating</h6>
                                    <span class="font700">5/5</span>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-3">
                    <div class="card top_report">
                        <div class="body">
                            <div class="clearfix">
                                <div class="float-left">
                                    <i class="fa fa-5x fa-battery-half text-col-blue"></i>
                                </div>
                                <div class="number float-right text-right">
                                    <h6>Pending Requests</h6>
                                    <span class="font700">50</span>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\htdocs\samie_dallas_dashboard\resources\views/home.blade.php ENDPATH**/ ?>