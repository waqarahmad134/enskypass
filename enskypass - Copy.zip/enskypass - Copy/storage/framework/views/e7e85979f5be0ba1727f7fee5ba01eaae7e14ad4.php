<?php $__env->startSection('content'); ?>

    <div class="page-content">
        <div class="main-wrapper">
            <div class="col">
                <div class="card">
                    <div class="card-body">
                        <?php if(Session::has('message')): ?>
                        <p class="alert alert-<?php echo e(Session::get('alert')); ?>"><?php echo e(Session::get('message')); ?></p>
                        <?php endif; ?>
                        <div class="row mt-2">
                            <div class="d-flex align-items-center"><b>View Sub-Category of: &nbsp;</b></div>
                            <form action="<?php echo e(route('category.view_sub')); ?>" method="post" class="d-flex">
                                <?php echo csrf_field(); ?>
                                <select class="form-control" name="cate_id">
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>&nbsp;
                                <button type="submit" class="btn btn-primary">View</button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <?php if(isset($sub_categories) && $sub_categories->count() > 0): ?>
                                <table class="table table-bordered table-hover js-basic-example dataTable table-custom" style="width: 100%;">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Image</th>
                                            <th>Name</th>
                                            <th>Color</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($sub_category->id); ?></td>
                                                <td><?php echo e($sub_category->image); ?></td>
                                                <td><?php echo e($sub_category->name); ?></td>
                                                <td><?php echo e($sub_category->background_color); ?></td>
                                                <td>
                                                    <?php if(isset($sub_category->sub_category) && $sub_category->sub_category->count() > 0): ?>
                                                        <a href="<?php echo e(route('category.show.sub',['category'=>$category->id,'sub_category'=>$sub_category->id])); ?>" class="btn btn-primary">View</a>
                                                    <?php endif; ?>
                                                    <a href="<?php echo e(route('category.edit',['category'=>$sub_category])); ?>" class="btn btn-primary">Edit</a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th>ID</th>
                                            <th>Image</th>
                                            <th>Name</th>
                                            <th>Color</th>
                                            <th>Action</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/devgloca/public_html/appsdashboard/resources/views/categorymanagement/load_sub_category.blade.php ENDPATH**/ ?>